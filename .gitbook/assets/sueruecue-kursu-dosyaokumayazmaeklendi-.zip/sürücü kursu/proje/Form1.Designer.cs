﻿
namespace proje
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbMüsteriAdi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbMüsteriSoyadi = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbCepTelefonu = new System.Windows.Forms.TextBox();
            this.tbMüsteriAdresi = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tbToplamTutar = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.btnKayitSil = new System.Windows.Forms.Button();
            this.btnKayitEkle = new System.Windows.Forms.Button();
            this.btnKayitGuncelle = new System.Windows.Forms.Button();
            this.dtTarih = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.cbEhliyetTuru = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbTcNo = new System.Windows.Forms.TextBox();
            this.btnTemizle = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.btnOku = new System.Windows.Forms.Button();
            this.btnYaz = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Yellow;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(342, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Müşteri Adı :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(339, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(482, 35);
            this.label2.TabIndex = 0;
            this.label2.Text = "Sürücü Kursu Müşteri Kayıt Sistemi";
            // 
            // tbMüsteriAdi
            // 
            this.tbMüsteriAdi.Location = new System.Drawing.Point(488, 81);
            this.tbMüsteriAdi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbMüsteriAdi.Name = "tbMüsteriAdi";
            this.tbMüsteriAdi.Size = new System.Drawing.Size(145, 27);
            this.tbMüsteriAdi.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Yellow;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(659, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 22);
            this.label3.TabIndex = 0;
            this.label3.Text = "Müşteri Soyadı :";
            // 
            // tbMüsteriSoyadi
            // 
            this.tbMüsteriSoyadi.Location = new System.Drawing.Point(806, 81);
            this.tbMüsteriSoyadi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbMüsteriSoyadi.Name = "tbMüsteriSoyadi";
            this.tbMüsteriSoyadi.Size = new System.Drawing.Size(145, 27);
            this.tbMüsteriSoyadi.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Yellow;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(659, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 22);
            this.label4.TabIndex = 0;
            this.label4.Text = "Cep Telefonu :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Yellow;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(342, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 22);
            this.label5.TabIndex = 0;
            this.label5.Text = "Adres :";
            // 
            // tbCepTelefonu
            // 
            this.tbCepTelefonu.Location = new System.Drawing.Point(806, 124);
            this.tbCepTelefonu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbCepTelefonu.Name = "tbCepTelefonu";
            this.tbCepTelefonu.Size = new System.Drawing.Size(145, 27);
            this.tbCepTelefonu.TabIndex = 1;
            // 
            // tbMüsteriAdresi
            // 
            this.tbMüsteriAdresi.Location = new System.Drawing.Point(488, 169);
            this.tbMüsteriAdresi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbMüsteriAdresi.Name = "tbMüsteriAdresi";
            this.tbMüsteriAdresi.Size = new System.Drawing.Size(145, 27);
            this.tbMüsteriAdresi.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Yellow;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(659, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 22);
            this.label6.TabIndex = 0;
            this.label6.Text = "Ehliyet Türü  :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Yellow;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(657, 223);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(152, 22);
            this.label9.TabIndex = 0;
            this.label9.Text = "Ödenecek Tutar :";
            // 
            // tbToplamTutar
            // 
            this.tbToplamTutar.Location = new System.Drawing.Point(806, 212);
            this.tbToplamTutar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbToplamTutar.Name = "tbToplamTutar";
            this.tbToplamTutar.Size = new System.Drawing.Size(145, 27);
            this.tbToplamTutar.TabIndex = 1;
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.White;
            this.listView1.ForeColor = System.Drawing.Color.Black;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(86, 481);
            this.listView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(918, 341);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // btnKayitSil
            // 
            this.btnKayitSil.BackColor = System.Drawing.Color.Transparent;
            this.btnKayitSil.BackgroundImage = global::proje.Properties.Resources.kayitsilme;
            this.btnKayitSil.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKayitSil.ForeColor = System.Drawing.Color.Transparent;
            this.btnKayitSil.Location = new System.Drawing.Point(559, 344);
            this.btnKayitSil.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnKayitSil.Name = "btnKayitSil";
            this.btnKayitSil.Size = new System.Drawing.Size(138, 129);
            this.btnKayitSil.TabIndex = 3;
            this.btnKayitSil.UseVisualStyleBackColor = false;
            this.btnKayitSil.Click += new System.EventHandler(this.btnKayitSil_Click);
            // 
            // btnKayitEkle
            // 
            this.btnKayitEkle.BackColor = System.Drawing.Color.Transparent;
            this.btnKayitEkle.BackgroundImage = global::proje.Properties.Resources.kayitekleme;
            this.btnKayitEkle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKayitEkle.ForeColor = System.Drawing.Color.Transparent;
            this.btnKayitEkle.Location = new System.Drawing.Point(86, 344);
            this.btnKayitEkle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnKayitEkle.Name = "btnKayitEkle";
            this.btnKayitEkle.Size = new System.Drawing.Size(138, 129);
            this.btnKayitEkle.TabIndex = 3;
            this.btnKayitEkle.UseVisualStyleBackColor = false;
            this.btnKayitEkle.Click += new System.EventHandler(this.btnKayitEkle_Click);
            // 
            // btnKayitGuncelle
            // 
            this.btnKayitGuncelle.BackColor = System.Drawing.Color.Transparent;
            this.btnKayitGuncelle.BackgroundImage = global::proje.Properties.Resources.guncelleme;
            this.btnKayitGuncelle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKayitGuncelle.ForeColor = System.Drawing.Color.Transparent;
            this.btnKayitGuncelle.Location = new System.Drawing.Point(339, 344);
            this.btnKayitGuncelle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnKayitGuncelle.Name = "btnKayitGuncelle";
            this.btnKayitGuncelle.Size = new System.Drawing.Size(138, 129);
            this.btnKayitGuncelle.TabIndex = 3;
            this.btnKayitGuncelle.UseVisualStyleBackColor = false;
            this.btnKayitGuncelle.Click += new System.EventHandler(this.btnKayitGuncelle_Click);
            // 
            // dtTarih
            // 
            this.dtTarih.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtTarih.Location = new System.Drawing.Point(488, 215);
            this.dtTarih.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtTarih.Name = "dtTarih";
            this.dtTarih.Size = new System.Drawing.Size(145, 27);
            this.dtTarih.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Yellow;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(342, 220);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(113, 22);
            this.label10.TabIndex = 0;
            this.label10.Text = "Kayıt Tarih :";
            // 
            // cbEhliyetTuru
            // 
            this.cbEhliyetTuru.FormattingEnabled = true;
            this.cbEhliyetTuru.Items.AddRange(new object[] {
            "Motor Ehliyeti",
            "Araç Ehliyeti"});
            this.cbEhliyetTuru.Location = new System.Drawing.Point(806, 169);
            this.cbEhliyetTuru.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbEhliyetTuru.Name = "cbEhliyetTuru";
            this.cbEhliyetTuru.Size = new System.Drawing.Size(145, 28);
            this.cbEhliyetTuru.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Yellow;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(342, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 22);
            this.label7.TabIndex = 0;
            this.label7.Text = "Müşteri Tc No:";
            // 
            // tbTcNo
            // 
            this.tbTcNo.Location = new System.Drawing.Point(488, 124);
            this.tbTcNo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbTcNo.Name = "tbTcNo";
            this.tbTcNo.Size = new System.Drawing.Size(145, 27);
            this.tbTcNo.TabIndex = 1;
            // 
            // btnTemizle
            // 
            this.btnTemizle.BackColor = System.Drawing.Color.Transparent;
            this.btnTemizle.BackgroundImage = global::proje.Properties.Resources.temizle;
            this.btnTemizle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTemizle.ForeColor = System.Drawing.Color.Transparent;
            this.btnTemizle.Location = new System.Drawing.Point(807, 344);
            this.btnTemizle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTemizle.Name = "btnTemizle";
            this.btnTemizle.Size = new System.Drawing.Size(138, 129);
            this.btnTemizle.TabIndex = 3;
            this.btnTemizle.UseVisualStyleBackColor = false;
            this.btnTemizle.Click += new System.EventHandler(this.btnTemizle_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.BackgroundImage = global::proje.Properties.Resources.cikisbutonu;
            this.btnCikis.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCikis.Location = new System.Drawing.Point(0, 829);
            this.btnCikis.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(78, 79);
            this.btnCikis.TabIndex = 6;
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // btnOku
            // 
            this.btnOku.Location = new System.Drawing.Point(586, 830);
            this.btnOku.Name = "btnOku";
            this.btnOku.Size = new System.Drawing.Size(418, 29);
            this.btnOku.TabIndex = 7;
            this.btnOku.Text = "Oku";
            this.btnOku.UseVisualStyleBackColor = true;
            this.btnOku.Click += new System.EventHandler(this.btnOku_Click);
            // 
            // btnYaz
            // 
            this.btnYaz.Location = new System.Drawing.Point(586, 865);
            this.btnYaz.Name = "btnYaz";
            this.btnYaz.Size = new System.Drawing.Size(418, 29);
            this.btnYaz.TabIndex = 8;
            this.btnYaz.Text = "Yaz";
            this.btnYaz.UseVisualStyleBackColor = true;
            this.btnYaz.Click += new System.EventHandler(this.btnYaz_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = global::proje.Properties.Resources.arkaplan;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1039, 911);
            this.Controls.Add(this.btnYaz);
            this.Controls.Add(this.btnOku);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.cbEhliyetTuru);
            this.Controls.Add(this.dtTarih);
            this.Controls.Add(this.btnKayitGuncelle);
            this.Controls.Add(this.btnKayitEkle);
            this.Controls.Add(this.btnTemizle);
            this.Controls.Add(this.btnKayitSil);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.tbMüsteriAdresi);
            this.Controls.Add(this.tbCepTelefonu);
            this.Controls.Add(this.tbToplamTutar);
            this.Controls.Add(this.tbMüsteriSoyadi);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tbTcNo);
            this.Controls.Add(this.tbMüsteriAdi);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbMüsteriAdi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbMüsteriSoyadi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbCepTelefonu;
        private System.Windows.Forms.TextBox tbMüsteriAdresi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbToplamTutar;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btnKayitSil;
        private System.Windows.Forms.Button btnKayitEkle;
        private System.Windows.Forms.Button btnKayitGuncelle;
        private System.Windows.Forms.DateTimePicker dtTarih;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cbEhliyetTuru;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbTcNo;
        private System.Windows.Forms.Button btnTemizle;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Button btnOku;
        private System.Windows.Forms.Button btnYaz;
    }
}

