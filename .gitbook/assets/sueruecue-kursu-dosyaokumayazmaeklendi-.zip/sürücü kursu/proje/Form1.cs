﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.FullRowSelect = true;
            listView1.View = View.Details;
            listView1.Columns.Add("Tc Kimlik No");
            listView1.Columns.Add("Müşteri Adı");
            listView1.Columns.Add("Müşteri Soyadi");
            listView1.Columns.Add("Ev Telefonu");
            listView1.Columns.Add("Adres");
            listView1.Columns.Add("Ehliyet Türü");
            listView1.Columns.Add("Ödenecek Tutar");
            listView1.Columns.Add("Tarih");

            // sütunların otomatik boyutlanması
            for (int i = 0; i < listView1.Columns.Count; i++)
            {
                listView1.Columns[i].Width = -2;
            }
        }

        private void btnKayitSil_Click(object sender, EventArgs e)
        {
            //Secilen Kaydı Silmek
            int secimSayisi = listView1.SelectedItems.Count;

            foreach (ListViewItem bilgi in listView1.SelectedItems)
            {
                bilgi.Remove();
            }
            MessageBox.Show(secimSayisi + " adet kayıt silindi.");
        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {//ListView deki bütün Kayıtları sil , sildikten sonrada bana mesaj ver
            listView1.Items.Clear();
            MessageBox.Show("Kayıtlar Temizlendi.");
        }

        private void btnKayitEkle_Click(object sender, EventArgs e)
        {//KAYIT EKLEME
            if (tbMüsteriAdi.Text.Trim() == "" || tbMüsteriSoyadi.Text.Trim() == "" || tbTcNo.Text.Trim() == ""
                || tbCepTelefonu.Text.Trim() == "" || tbMüsteriAdresi.Text.Trim() == "" ||         
                cbEhliyetTuru.Text.Trim() == "" || tbToplamTutar.Text.Trim() == "" || dtTarih.Text.Trim() == "")
                MessageBox.Show("Tüm Bilgilerinizi Lütfen Giriniz..."); //HERHANGİ BİR TEXTBOX , BOŞ BIRAKILMAMALIDIR , BOŞ BIRAKILIRSA BANA UYARI VER
            else
            {// diziyi bir ListViewItem nesnesi haline getiriyoruz
                string[] row = { tbTcNo.Text, tbMüsteriAdi.Text, tbMüsteriSoyadi.Text, tbCepTelefonu.Text, tbMüsteriAdresi.Text, cbEhliyetTuru.Text, tbToplamTutar.Text, dtTarih.Text };
                var satir = new ListViewItem(row);
                bool TC = TC_Kontrol(tbTcNo.Text);// Aynı Numaralı TC kimlik numarası istemediğimiz için burda bir TC kontrolu yapıyoruz
                bool Mukerrer = Mukerrer_Kontrol(satir);//Mükerrer kayıt olmasını istemediğimiz için bir Mükerrer kayıt kontrolu yapıyoruz
                
                if (Mukerrer)// Eğer Mükerrer Kontrol metodumuz true dönerse ,kayıt etmek istediğimiz satır mükerrer demektir
                    MessageBox.Show("Aynı bilgilere sahip başka bir kayıt zaten mevcut");
                else
                {
                    if (TC)//Tc kontrol metodumuz true dönerse , kayıt etmek istediğimiz satırdaki TC numarası ile başka kayıt var demektir.
                        MessageBox.Show("Aynı TC bilgisine sahip başka bir kayıt zaten mevcut");
                    else
                        listView1.Items.Add(satir);


                }
                // YAPILAN HER KAYIT SONRASINDA TEXTBOXLARIN TEMİZLENMESİ İÇİN YAZILAN KOD ;
                tbMüsteriAdi.Clear();
                tbMüsteriSoyadi.Clear();
                tbTcNo.Clear();
                tbCepTelefonu.Clear();
                tbMüsteriAdresi.Clear();
                tbToplamTutar.Clear();


            }
        }

        private bool TC_Kontrol(string TC)
        {//GERİ DÖNÜŞ DEĞERİ OLARAK BOOL TANIMLADIK

            bool b = false;
            for (int i = 0; i < listView1.Items.Count; i++)//BİR FOR DÖNGÜSÜ BAŞLATIYORUZ. LİSTVİEW NESNESİNDEKİ İTEM SAYISI KADAR DÖNECEK
            {
                if (listView1.Items[i].SubItems[0].Text == TC)
                {
                    b = true;
                    break;//ListView içindeki bir satırın Subitem yani ilk kolondaki verisi ile kayıt etmek istediğimiz TC aynı ise
                          //Değişkenimizi True Yapıyoruz ve Döngüyü Kırıyoruz
                }
            }
            return b;
        }

        private bool Mukerrer_Kontrol(ListViewItem liv)
        {// Geri dönüş değeri almak için önce bir bool değişken tanımladık 
            
            bool b = false;
            int kolon_sayi = listView1.Columns.Count;//ListView nesnesindeki kolon sayısını aldık
            int kontrol = 0;//Kontrol için kontrol değişkeni tanımladık
            for (int i = 0; i < listView1.Items.Count; i++)//ListView satırları arasında döngü hazırladık
            {
                kontrol = 0;//Her satırda Subitemler için kontrol yapacağımız için kontrol değişkenini sıfırladık
                for (int j = 0; j < listView1.Items[i].SubItems.Count; j++)//Sırası ile ListView itemler arasında gezerken,
                                                                           //listViewItem ler içindeki subitemler arasında gezinmek için döngü başlattık
                {
                    if (listView1.Items[i].SubItems[j].Text == liv.SubItems[j].Text)//İlk hücredeki veri ile ,Eklemek istediğimiz Satırın ilk hücresi aynı ise
                                                                                    //kontrol değişkenini 1 arttırıyoruz
                    {
                        kontrol++;
                    }
                }
                if (kontrol == kolon_sayi)//Eğer satırdaki tüm hücrelerdeki veriler aynı ise eklemek istediğimiz kayıt mükerrer olacaktır
                                          //Eğer kolon sayısı ile kontrol edilen ve aynı veriye sahip olan hücre sayısı aynı ise ;
                {
                    b = true;//Satırdaki tüm bilgiler eklemek istediğimiz satırdaki bilgiler ile aynıdır .Bu yüzden bool değişkenini true yapıyoruz
                    break;
                }
                else 
                {
                    b = false;
                }
            }
            return b;
        }

        private void btnKayitGuncelle_Click(object sender, EventArgs e)
        {
            /*Burada listView1(listeden) seçilen kaydın ,textboxlara girilen yeni kaydın güncellenmesi bulunmaktadır
             */
            if (listView1.SelectedItems != null)
            {
                ListViewItem item = listView1.SelectedItems[0];
                item.SubItems[0].Text = tbTcNo.Text;
                item.SubItems[1].Text = tbMüsteriAdi.Text;
                item.SubItems[2].Text = tbMüsteriSoyadi.Text;
                item.SubItems[3].Text = tbCepTelefonu.Text;
                item.SubItems[4].Text = tbMüsteriAdresi.Text;
                item.SubItems[5].Text = cbEhliyetTuru.Text;
                item.SubItems[6].Text = tbToplamTutar.Text;
                item.SubItems[7].Text = dtTarih.Text;
            }
           
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {//ÇIKIŞ BUTONUNA BASTIĞIMDA FORMU KAPAT , PROGRAMI DURDUR
            this.Close();
        }

        private void btnOku_Click(object sender, EventArgs e)
        {

            //Kayitlar dosyasında ki veriler aralarında ki virgüle göre gruplandırılmaktadır.
            List<string> data = File.ReadAllLines("kayitlar.txt").ToList();
            foreach (string d in data)
            {
                string[] items = d.Split(new char[] { ',' },
                    StringSplitOptions.RemoveEmptyEntries);
                listView1.Items.Add(new ListViewItem(items));
            }
        }

        private void btnYaz_Click(object sender, EventArgs e)
        {
            // kayıtlar dosyasında ki verileri aralarına virgül koyarak yaz.
            using (StreamWriter sw = new StreamWriter("kayitlar.txt"))
            {
                if (listView1.Items.Count > 0) // listview boş değil ise 
                {
                    StringBuilder sb = new StringBuilder();
                    foreach (ListViewItem lvi in listView1.Items)
                    {
                        sb = new StringBuilder();
                        foreach (ListViewItem.ListViewSubItem listViewSubItem in lvi.SubItems)
                        {
                            sb.Append(string.Format(listViewSubItem.Text+","));
                        }
                        sw.WriteLine(sb.ToString());
                    }
                    sw.WriteLine();
                }
            }
            MessageBox.Show("Dosya proje yoluna kaydedildi");
        }

    }
    }

    

