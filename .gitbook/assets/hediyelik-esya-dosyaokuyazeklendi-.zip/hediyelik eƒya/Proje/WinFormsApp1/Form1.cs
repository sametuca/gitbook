﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Kullanici;//kullanıcı stringi oluşturup textBox1 ile eşittirmek için.

            string sifre;//parola stringi oluşturup textBox2 ile eşittirmek için.

            Kullanici = textBox1.Text;// Oluşturduğumuz kullanıcı stringini textBox1’e bağlamak için

            sifre = textBox2.Text;//Oluşturduğumuz parola stringini textBox2’ye bağlamak için

            if (Kullanici == "Admin" && sifre == "123456")//eğer kullanıcı adı Admin, şifre 123456 ise,.. 
            {
                MessageBox.Show("BAŞARALI GİRİŞ YAPTINIZ ");//Doğru giriş yaptığım için bana bir mesaj ver,..
                this.Hide();//bunu gizle, 
                Form2 frm = new Form2();//form2’yi aç 
                frm.Show();
               

            }
            else //eğer şifre yanlış ise ..
            {
                MessageBox.Show("Kullanıcı Adı Veya Şifreniz Yanlış!!!");//MessageBox ile bana yanlış olduğunu bildir
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 frm = new Form2();//form2’yi aç 
            frm.Show();

        }
    }
}


