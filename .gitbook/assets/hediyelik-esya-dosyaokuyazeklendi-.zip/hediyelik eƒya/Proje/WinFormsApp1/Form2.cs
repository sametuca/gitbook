﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(comboBox1.Text);//combobox1 deki seçileni listbox1 e ekle
            listBox2.Items.Add(textBox1.Text);// textbox1 de yazılanı listbox2 ye ekle
            int adet = Convert.ToInt32(textBox1.Text);//textbox1 e sadece rakam girilmesini sağla
            int sonuc = 0;//sonuc değişkenini 0 dan başlat
            if (comboBox1.Text == "KUPA BARDAK")//combobax 1 de ''KUPA BARDAK '' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 1;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "TİŞÖRT") //combobax 1 de ''TİŞÖRT '' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 2;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "İSİMLİK")//combobax 1 de ''İSİMLİK '' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 4;//;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "ATKI")//combobax 1 de ''ATKI '' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 1;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "DUVAR SAATİ")//combobax 1 de ''DUVAR SAATİ '' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 2;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "MASA SAATİ")//combobax 1 de ''MASA SAATİ '' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 3;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "ŞAPKA")//combobax 1 de ''ŞAPKA '' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 2;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "MASA ÜSTÜ KİTAPLIK")//combobax 1 de ''MASA ÜSTÜ KİTAPLIK '' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 8;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "ANAHTARLIK")//combobax 1 de ''ANAHTARLIK '' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 4;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "KAR KÜRESİ")//combobax 1 de ''KAR KÜRESİ'' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 10;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "OYUNCAK AYI")//combobax 1 de ''OYUNCAK AYI'' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 7;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "PARFÜM")//combobax 1 de ''PARFÜM'' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 6;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "ÇANTA")//combobax 1 de ''ÇANTA'' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 15;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }
            if (comboBox1.Text == "OYUNCAK ARABA")//combobax 1 de ''OYUNCAK ARABA'' SEÇİLDİYSE BUNU...
            {
                sonuc = adet * 12;//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata
            }

            listBox3.Items.Add(sonuc);//LİSTBOX3 e  textbox1e(adet) yazılan rakam ile çarp sonuc değişkenine ata ve listbox3 e sonucu yazdır
            int tutar = 0;//tutar değişkeni tanımladım ve 0 a eşitledim

            for (int i = 0; i < listBox3.Items.Count; i++)//for döngüsü kurup int ile i değişkeni tanımladım ve  i listbox3 e eklenen sayılardan küçük olduğunu ve i yi 1 arttırmasını söyledim
            {
                tutar += Convert.ToInt32(listBox3.Items[i]);//tutar değişkenini convert edip listbox3deki yazılan verileri i ye atadım
            }
         
            label2.Text = tutar.ToString();//tutar değişkenindeki toplamı label2 ye yazdır

            textBox1.Clear();//ekledikten sonra textbox1 i temizle
            comboBox1.Text = "";//ekledikten sonra combobox1 i temizle
        }
          
        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndices.Count > 0 && listBox2.SelectedIndices.Count > 0 && listBox3.SelectedIndices.Count > 0)//Listbox1,listbox2,listbox3 aynı anda seçtiğinden emin ol 
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndices[0]);//eğer listbox1 ,..
                listBox2.Items.RemoveAt(listBox2.SelectedIndices[0]);//listbox2 yi ve ...
                listBox3.Items.RemoveAt(listBox3.SelectedIndices[0]);//listbox3 aynı anda seçildiyse sil
            }
            else//aynı anda seçilmediyse...
            {
                MessageBox.Show("SATIRDAKİLERİN HEPSİNİ SEÇTİĞİNİZDEN EMİN OLUN");//bana bu mesaj ile hatırlat
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //LİSTBOXDA ÇOKLU SEÇME KODU
            listBox1.SelectionMode = SelectionMode.MultiSimple; 
            listBox2.SelectionMode = SelectionMode.MultiSimple;
            listBox3.SelectionMode = SelectionMode.MultiSimple;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Çıkış yapmak istediğinden eminmmisin diye cevabı evet yada hayır olan butonlar ile sor
            if (MessageBox.Show("Çıkmak İstediğinize Eminmisiniz ?", " UYARI..!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnKayitlariGetir_Click(object sender, EventArgs e)
        {
            var reader = File.OpenText(AppDomain.CurrentDomain.BaseDirectory + "\\ürünAdi.txt");
            string writer;
            while ((writer = reader.ReadLine()) != null)
            {
                listBox1.Items.Add(writer.ToString());
            }
            reader.Close();

            var readerTwo = File.OpenText(AppDomain.CurrentDomain.BaseDirectory + "\\ürünAdeti.txt");
            string writerTwo;
            while ((writerTwo = readerTwo.ReadLine()) != null)
            {
                listBox2.Items.Add(writerTwo.ToString());
            }
            readerTwo.Close();

            var readerThree = File.OpenText(AppDomain.CurrentDomain.BaseDirectory + "\\ürünFiyati.txt");
            string writerThree;
            while ((writerThree = readerThree.ReadLine()) != null)
            {
                listBox3.Items.Add(writerThree.ToString());
            }
            readerThree.Close();
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {

            var fileStream = new FileStream("ürünAdi.txt", FileMode.Append, FileAccess.Write, FileShare.Write);
            var streamWriter = new StreamWriter(fileStream);
            foreach (var items in listBox1.Items)
            {
                streamWriter.WriteLine(items);
            }
            streamWriter.Close();
            fileStream.Close();
            var filestreamTwo = new FileStream("ürünAdeti.txt", FileMode.Append, FileAccess.Write, FileShare.Write);
            var streamWriterTwo = new StreamWriter(filestreamTwo);
            foreach (var items in listBox2.Items)
            {
                streamWriterTwo.WriteLine(items);
            }
            streamWriterTwo.Close();
            filestreamTwo.Close();
            var fileStreamThree = new FileStream("ürünFiyati.txt", FileMode.Append, FileAccess.Write, FileShare.Write);
            var streamWriterThree = new StreamWriter(fileStreamThree);
            foreach (var items in listBox3.Items)
            {
                streamWriterThree.WriteLine(items);
            }
            streamWriterThree.Close();
            fileStreamThree.Close();

            MessageBox.Show("Ürünler proje dosyasına kaydedildi", "Başarılı", MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
    }
    }

